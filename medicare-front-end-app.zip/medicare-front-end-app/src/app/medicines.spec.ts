import { Medicines } from './medicines';

describe('Medicines', () => {
  it('should create an instance', () => {
    expect(new Medicines()).toBeTruthy();
  });
});
