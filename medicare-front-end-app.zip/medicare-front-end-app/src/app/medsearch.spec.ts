import { Medsearch } from './medsearch';

describe('Medsearch', () => {
  it('should create an instance', () => {
    expect(new Medsearch()).toBeTruthy();
  });
});
