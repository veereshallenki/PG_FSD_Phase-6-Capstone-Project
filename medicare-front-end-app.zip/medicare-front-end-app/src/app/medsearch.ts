import { OnInit } from "@angular/core";
import { FormGroup } from "@angular/forms";

export class Medsearch {
    //SearchRef:FormGroup
    constructor(
        public name: string) { };
}
